bubble game

rules:
-> you will have 60 second.
-> you have to click on the bubble which is having same number as hit.
-> if you have selected correct bubble you will get 10 point.
-> if you have selected incorrect bubble no point will be deducted.
